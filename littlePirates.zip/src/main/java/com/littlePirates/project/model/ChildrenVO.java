package com.littlePirates.project.model;

public class ChildrenVO {

	private String nurRegion;
	private String nurName;
	private String nurType;
	private String nurCondition;
	private String nurZipcode;
	private String nurAddress;
	private String nurTel;
	private String nurBus;
	private int nurClass;
	private int nurNo;

	public String getNurRegion() {
		return nurRegion;
	}

	public void setNurRegion(String nurRegion) {
		this.nurRegion = nurRegion;
	}

	public String getNurName() {
		return nurName;
	}

	public void setNurName(String nurName) {
		this.nurName = nurName;
	}

	public String getNurType() {
		return nurType;
	}

	public void setNurType(String nurType) {
		this.nurType = nurType;
	}

	public String getNurCondition() {
		return nurCondition;
	}

	public void setNurCondition(String nurCondition) {
		this.nurCondition = nurCondition;
	}

	public String getNurZipcode() {
		return nurZipcode;
	}

	public void setNurZipcode(String nurZipcode) {
		this.nurZipcode = nurZipcode;
	}

	public String getNurAddress() {
		return nurAddress;
	}

	public void setNurAddress(String nurAddress) {
		this.nurAddress = nurAddress;
	}

	public String getNurTel() {
		return nurTel;
	}

	public void setNurTel(String nurTel) {
		this.nurTel = nurTel;
	}

	public String getNurBus() {
		return nurBus;
	}

	public void setNurBus(String nurBus) {
		this.nurBus = nurBus;
	}

	public int getNurClass() {
		return nurClass;
	}

	public void setNurClass(int nurClass) {
		this.nurClass = nurClass;
	}

	public int getNurNo() {
		return nurNo;
	}

	public void setNurNo(int nurNo) {
		this.nurNo = nurNo;
	}

	public int getNurTeacher() {
		return nurTeacher;
	}

	public void setNurTeacher(int nurTeacher) {
		this.nurTeacher = nurTeacher;
	}

	public int getNurMax() {
		return nurMax;
	}

	public void setNurMax(int nurMax) {
		this.nurMax = nurMax;
	}

	private int nurTeacher;
	private int nurMax;

}
