package com.littlePirates.project.model;

public class ChildVO {

}
