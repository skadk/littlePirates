package com.littlePirates.project.model;

public class KcreviewVO {
	private int kcrNo;
	private String kcrTitle;
	private String kcrText;
	private String kcrDate;
	private String memId;
	private int kcNo;
		
	public int getKcrNo() {
		return kcrNo;
	}
	public void setKcrNo(int kcrNo) {
		this.kcrNo = kcrNo;
	}
	public String getKcrTitle() {
		return kcrTitle;
	}
	public void setKcrTitle(String kcrTitle) {
		this.kcrTitle = kcrTitle;
	}
	public String getKcrText() {
		return kcrText;
	}
	public void setKcrText(String kcrText) {
		this.kcrText = kcrText;
	}
	public String getKcrDate() {
		return kcrDate;
	}
	public void setKcrDate(String kcrDate) {
		this.kcrDate = kcrDate;
	}
	public String getMemId() {
		return memId;
	}
	public void setMemId(String memId) {
		this.memId = memId;
	}
	public int getKcNo() {
		return kcNo;
	}
	public void setKcNo(int kcNo) {
		this.kcNo = kcNo;
	}

}
