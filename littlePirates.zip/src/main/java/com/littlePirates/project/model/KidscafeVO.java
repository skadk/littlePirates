package com.littlePirates.project.model;

public class KidscafeVO {
	private String kcNo;
	private String kcName;
	private float kclat;
	private float kcLng;
	private String kcAddress;
	private String kcphone;
	
	public String getKcNo() {
		return kcNo;
	}
	public void setKcNo(String kcNo) {
		this.kcNo = kcNo;
	}
	public String getKcName() {
		return kcName;
	}
	public void setKcName(String kcName) {
		this.kcName = kcName;
	}
	public float getKclat() {
		return kclat;
	}
	public void setKclat(float kclat) {
		this.kclat = kclat;
	}
	public float getKcLng() {
		return kcLng;
	}
	public void setKcLng(float kcLng) {
		this.kcLng = kcLng;
	}
	public String getKcAddress() {
		return kcAddress;
	}
	public void setKcAddress(String kcAddress) {
		this.kcAddress = kcAddress;
	}
	public String getKcphone() {
		return kcphone;
	}
	public void setKcphone(String kcphone) {
		this.kcphone = kcphone;
	}
}
