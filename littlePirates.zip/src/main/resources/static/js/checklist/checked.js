/**
 * 
 */
$(function() {
    $.ajax({
        url: "/checkList/checkList_Image",
        type: "post",
        success: function(data) {
            console.log(data.chlNo1_Checked);
            console.log(data.chlNo2_Checked);
            console.log(data.chlNo3_Checked);
            console.log(data.chlNo4_Checked);
            console.log(data.chlNo5_Checked);
            console.log(data.chlNo6_Checked);
            console.log(data.chlNo7_Checked);
            console.log(data.chlNo8_Checked);
            console.log(data.chlNo9_Checked);
        },
        error: function() {
            alert("error");
        }
    });
});